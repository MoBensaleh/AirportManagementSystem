package Startup;

/**
 * This class is only here for creating executable jar files
 */
public class Launcher {
    public static void main(String[] args) {
        AMS.main(args);
    }
}
