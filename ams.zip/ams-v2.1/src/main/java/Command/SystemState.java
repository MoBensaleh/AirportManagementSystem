package Command;

/*
  Portions of this file are inspired by the SystemState class from CMPT 270.
  Permission to use that file as a starting point has been obtained from
  the course instructor of CMPT 270 and 370.

  CMPT 270 Course material
  Copyright (c) 2020
  All rights reserved.
 */

import java.util.Map;

import Entities.Employee;
import Entities.Passenger;
import Singleton.AirportAccess;
import Singleton.EmployeeAccess;
import Singleton.PassengerAccess;
import javafx.scene.control.Alert;

/**
 * Prints the current state of the system to console output.
 */
public class SystemState implements Command{
    @Override
    public void execute() {
        String outString = "\nThe Airport system has the following employees registered:\n";
        String temp = "";
        for (Employee employee : EmployeeAccess.getInstance()) {
            temp += employee.toString();
        }
        outString += (temp.equals("")) ? "None\n" : temp;


        outString += "\nThe airport system has the following passengers registered:\n";
        temp = "";
        for (Passenger passenger : PassengerAccess.getInstance()) {
            temp += passenger.toString();
        }
        outString += (temp.equals("")) ? "None\n" : temp;


        outString += AirportAccess.getInstance();

        new Alert(Alert.AlertType.INFORMATION,outString);

    }
}

