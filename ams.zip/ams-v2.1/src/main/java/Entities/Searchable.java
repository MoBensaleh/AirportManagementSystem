package Entities;

import java.util.function.Predicate;

public interface Searchable {
    static Predicate search(String text) {
        return null;
    }

}
